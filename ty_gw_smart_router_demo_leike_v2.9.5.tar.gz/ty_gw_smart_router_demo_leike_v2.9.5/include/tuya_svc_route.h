#ifndef __COMPONENT_TUYA_ROUTE_SVC_H__
#define __COMPONENT_TUYA_ROUTE_SVC_H__

#include "tuya_cloud_types.h"
#include "tuya_cloud_com_defs.h"
#include "tuya_cloud_error_code.h"
#include "uni_log.h"
#include "tuya_iot_internal_api.h"

#define TY_ROUTE_DEV_NAME_MAX   64
#define TY_ROUTE_MAC_STR_LEN    18

typedef enum {
    TY_ROUTE_CMD_GET_ONLINE_LIST = 1,          
    TY_ROUTE_CMD_GET_BLACK_LIST = 2,
    TY_ROUTE_CMD_INVALD
        
} TY_ROUTE_CMD_E;

typedef enum {
    TY_ROUTE_PWD_INVALID = 0,
    TY_ROUTE_PWD_2_4G = 1,
    TY_ROUTE_PWD_5G = 2,
} TUYA_ROUTE_PWD_E;

typedef VOID (*TY_ROUTE_CMD_CB)(IN CONST TY_ROUTE_CMD_E cmd);
typedef VOID (*TY_ROUTE_QUERY_PWD_CB)(IN CONST TUYA_ROUTE_PWD_E type);
typedef VOID (*TY_ROUTE_SET_PWD_CB)(IN CONST TUYA_ROUTE_PWD_E type, IN CONST CHAR_T *pwd);

typedef struct {
    TY_ROUTE_CMD_CB         route_cmd_cb;
    TY_ROUTE_QUERY_PWD_CB   route_query_cb;
    TY_ROUTE_SET_PWD_CB     route_set_cb;
    
}TUYA_ROUTE_CBS_S;

typedef enum {
    TY_STA_CMD_ALLOW_NET = 1,          
    TY_STA_CMD_SPEED_LIMIT = 2,
    TY_STA_CMD_UP_LIMIT = 3,
    TY_STA_CMD_DOWN_LIMIT = 4,
    TY_STA_CMD_GET_ALL_CONFIG = 5,
    TTY_STA_CMD_INVALD
        
} TY_ROUTE_STA_CMD_E;

typedef VOID (*TY_ROUTE_STA_CMD_CB)(IN CONST TY_ROUTE_STA_CMD_E cmd, IN CONST CHAR_T *mac, 
                                    IN CONST UINT_T value);

typedef struct {
    TY_ROUTE_STA_CMD_CB     sta_cmd_cb;
    
}TUYA_ROUTE_STA_CBS_S;

typedef struct {
    CHAR_T      dev_name[TY_ROUTE_DEV_NAME_MAX];
    CHAR_T      mac[TY_ROUTE_MAC_STR_LEN];
    
}TUYA_ROUTE_DEV_LIST_S;

typedef struct {
    BOOL_T allow;
    BOOL_T limit; 
    UINT_T up_limit; 
    UINT_T down_limit; 

} TUYA_ROUTE_STA_CONF_S;

#ifdef __cplusplus
extern "C" {
#endif

OPERATE_RET tuya_route_service_init(IN CONST TUYA_ROUTE_CBS_S *p_route_cbs, 
                                    IN CONST TUYA_ROUTE_STA_CBS_S *p_sta_cbs);
OPERATE_RET tuya_route_rept_online_list(IN CONST USHORT_T dev_count, 
                                        IN CONST TUYA_ROUTE_DEV_LIST_S *p_list);
OPERATE_RET tuya_route_rept_pwd(IN CONST TUYA_ROUTE_PWD_E type, IN CONST CHAR_T *pwd);

OPERATE_RET tuya_route_rept_sta_allow_net(IN CONST CHAR_T *mac, 
                                          IN CONST BOOL_T allow, 
                                          IN CONST UINT_T sta_dpid);
OPERATE_RET tuya_route_rept_sta_limit(IN CONST CHAR_T *mac, 
                                      IN CONST BOOL_T limit, 
                                      IN CONST UINT_T sta_dpid);
OPERATE_RET tuya_route_rept_sta_up_limit(IN CONST CHAR_T *mac, 
                                         IN CONST UINT_T limit, 
                                         IN CONST UINT_T sta_dpid);
OPERATE_RET tuya_route_rept_sta_down_limit(IN CONST CHAR_T *mac, 
                                           IN CONST UINT_T limit, 
                                           IN CONST UINT_T sta_dpid);
OPERATE_RET tuya_route_rept_sta_all(IN CONST CHAR_T *mac, 
                                    IN CONST TUYA_ROUTE_STA_CONF_S *config, 
                                    IN CONST UINT_T sta_dpid);                                                 
OPERATE_RET tuya_route_sta_data_parse(IN CONST CHAR_T *data);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // __COMPONENT_TUYA_ROUTE_SVC_H__
