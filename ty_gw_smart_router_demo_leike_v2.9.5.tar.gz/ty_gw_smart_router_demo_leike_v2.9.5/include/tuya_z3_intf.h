#ifndef __TUYA_Z3_INTF_H
#define __TUYA_Z3_INTF_H

#ifdef __cplusplus
    extern "C" {
#endif

#include "tuya_z3.h"

typedef VOID (*TY_ZB_CHILD_PROC_SIGNAL_CB)(VOID);

typedef struct {
    TY_ZB_CHILD_PROC_SIGNAL_CB  child_proc_signal_cb;
} TY_Z3_PROC_SIG_CB_S;

typedef PVOID_T P_TASK_ID;
OPERATE_RET tuya_z3_intf_init(P_TASK_ID p_zb_tid, IN CONST CHAR_T *storage_dir);
OPERATE_RET tuya_z3_intf_get_coo_ver(CHAR_T *ver);
OPERATE_RET tuya_z3_intf_start();
OPERATE_RET tuya_z3_intf_scene_process(IN CONST SCE_ACTION_E action,IN CONST CHAR_T *dev_id,\
                            IN CONST CHAR_T *grp_id,IN CONST CHAR_T *sce_id);
OPERATE_RET tuya_z3_intf_dev_add_process(IN CONST GW_PERMIT_DEV_TP_T tp, \
                                         IN CONST BOOL_T permit, \
                                         IN CONST UINT_T timeout);
OPERATE_RET tuya_z3_intf_dev_del_process(IN CONST CHAR_T *dev_id);
OPERATE_RET tuya_z3_intf_bind_ifm_process(IN CONST CHAR_T *dev_id, IN CONST OPERATE_RET op_ret);
OPERATE_RET tuya_z3_intf_grp_process(IN CONST GRP_ACTION_E action, \
                                     IN CONST CHAR_T *dev_id, \
                                     IN CONST CHAR_T *grp_id);
VOID tuya_z3_intf_dev_reset(IN CONST CHAR_T *dev_id,IN DEV_RESET_TYPE_E type);
VOID tuya_z3_intf_nw_status(IN CONST TUYA_Z3_NET_STAT_E z3_net_stat);
VOID tuya_z3_intf_status_change(IN CONST GW_STATUS_E status, CHAR_T *auth_key);
VOID tuya_z3_intf_clear_all_dev_data(VOID);
VOID tuya_z3_intf_register_app_cb(IN CONST TUYA_Z3_APP_CB_S *cbs);
BOOL_T tuya_z3_intf_judge_home_security(TUYA_PLATEFORM_S *platform_info);
VOID tuya_z3_intf_register_proc_sig_cb(IN CONST TY_Z3_PROC_SIG_CB_S *cbs);

#ifdef __cplusplus
}
#endif

#endif

