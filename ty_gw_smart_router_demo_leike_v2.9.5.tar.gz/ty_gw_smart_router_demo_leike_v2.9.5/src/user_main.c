#include "tuya_cloud_types.h"
#include "tuya_cloud_error_code.h"
#include "tuya_cloud_com_defs.h"
#include "tuya_iot_com_api.h"
#include "uni_log.h"

#include "tuya_cloud_base_defs.h"
#include "tuya_iot_base_api.h"
#include "tuya_app_plateform_cfg.h"
#include "tuya_zigbee_service.h"
#include "tuya_gw_service.h"
#include "tuya_svc_route.h"
#include "svc_pegasus.h"

#include <stdio.h>
#include <unistd.h>

// UserTODO
// 网关固件版本，用于OTA管理，格式必须为"XX.XX.XX"，其中XX必须为数字
#ifndef USER_SW_VER
#define USER_SW_VER                 "1.2.3"
#endif

// 涂鸦云上的产品KEY，需登陆tuya.com创建产品分配唯一key
#define PRODUCT_KEY                 "jmdja3hfpsxev49g"
// SD本地配置存储路径，该路径必须对应一个可读写文件系统分区
#define CFG_STORAGE_PATH            "/var/tuya/cfg/"
// UUID和AUTHKEY用于涂鸦云设备的安全认证，每个设备所用key均为唯一
#define UUID                        "tuyab632ded9fcce501e"
#define AUTHKEY                     "lmUwYqHkRtwPwVpu14tGAKieOKM5bIkM"


#define SOC_OTA_FILE                "/tmp/gw_upgrade.ota"

#define DPID_BASE                   0

#define STA_DPID                    115

typedef enum {
    SIG_LOW = 0,
    SIG_MEDIUM = 1,
    SIG_HIGH = 2,
} WIFI_SIG_LEVEL_E;

typedef enum {
    ENC_NONE = 0,
    ENC_WAP2PSK = 1,
    ENC_WAPA_WAP2PSK = 2,
} WIFI_ENC_MODE_E;

typedef struct {
    CHAR_T              ssid[256];
    WIFI_SIG_LEVEL_E    sig_level;
    WIFI_ENC_MODE_E     enc_mode;
    BOOL_T              enable;
    BOOL_T              hide;
} ROUTE_WIFI_S;

ROUTE_WIFI_S route_wifi[2] = {
    {"leike_2.4G", SIG_LOW, ENC_NONE, FALSE, FALSE},
    {"leike_5G",   SIG_LOW, ENC_NONE, FALSE, FALSE},
};

/*****************************************************************************************************************/

// SOC设备升级相关代码开始
STATIC VOID __upgrade_notify_cb(IN CONST FW_UG_S *fw, IN CONST INT_T download_result, IN PVOID_T pri_data)
{
    FILE *p_upgrade_fd = (FILE *)pri_data;
    fclose(p_upgrade_fd);

    if(download_result == 0) {
        PR_DEBUG("Upgrade File Download Success");
        // UserTODO

    }else {
        PR_ERR("Upgrade File Download Fail.ret = %d", download_result);
    }
}

STATIC OPERATE_RET __get_file_data_cb(IN CONST FW_UG_S *fw, IN CONST UINT_T total_len, IN CONST UINT_T offset,
                                      IN CONST BYTE_T *data, IN CONST UINT_T len, OUT UINT_T *remain_len, IN PVOID_T pri_data)
{
//    PR_DEBUG("Rev File Data");
//    PR_DEBUG("Total_len:%u", total_len);
//    PR_DEBUG("Offset:%u Len:%u", offset, len);
    FILE *p_upgrade_fd = (FILE *)pri_data;
    fwrite(data, 1, len, p_upgrade_fd);
    *remain_len = 0;

    return OPRT_OK;
}

// GW设备升级入口
VOID __gw_dev_rev_upgrade_info_cb(IN CONST FW_UG_S *fw)
{
    PR_DEBUG("GW Rev Upgrade Info");
    PR_DEBUG("fw->tp:%d", fw->tp);
    PR_DEBUG("fw->fw_url:%s", fw->fw_url);
    PR_DEBUG("fw->fw_hmac:%s", fw->fw_hmac);
    PR_DEBUG("fw->sw_ver:%s", fw->sw_ver);
    PR_DEBUG("fw->file_size:%u", fw->file_size);

    FILE *p_upgrade_fd = fopen(SOC_OTA_FILE, "w+b");
    if(NULL == p_upgrade_fd){
        PR_ERR("open upgrade file fail. upgrade fail %s", SOC_OTA_FILE);
        return;
    }
    OPERATE_RET op_ret = tuya_iot_upgrade_gw(fw, __get_file_data_cb, __upgrade_notify_cb, p_upgrade_fd);
    if(OPRT_OK != op_ret) {
        PR_ERR("tuya_iot_upgrade_gw err:%d",op_ret);
    }
}

/*****************************************************************************************************************/

// GW设备云端状态变更回调
VOID __gw_dev_status_changed_cb(IN CONST GW_STATUS_E status)
{
    PR_DEBUG("GW TUYA-Cloud Status:%d", status);

    if(GW_ACTIVED == status) {
        OPERATE_RET op_ret = OPRT_OK;
    }
}

// GW设备复位请求入口
VOID __gw_dev_reset_inform_cb(GW_RESET_TYPE_E type)
{
    PR_DEBUG("GW Rev Reset Req, type: %d", type);

    // UserTODO
}

// GW设备进程重启请求入口
VOID __gw_dev_reboot_cb(VOID)
{
    PR_DEBUG("GW Rev Reboot Req");

    // UserTODO

    exit(0);
}

OPERATE_RET route_mqc_report_speed(IN CONST TY_OBJ_DP_S *p_dp_obj)
{
    OPERATE_RET ret = OPRT_OK;
    TY_OBJ_DP_S dp = {0x0};
    if(NULL == p_dp_obj || PROP_ENUM != p_dp_obj->type) {
        PR_ERR("paramater is invalid");
    }

    if (p_dp_obj->value.dp_enum == 0) { //Start
        memset(&dp, 0, sizeof(TY_OBJ_DP_S));
        dp.dpid = DPID_BASE + 4;
        dp.type = PROP_ENUM;
        dp.value.dp_enum = 2; //True
        ret = dev_report_dp_json_async(NULL, &dp, 1);
        if(OPRT_OK != ret) {
            PR_ERR("dev_report_dp_json_async ret:%d", ret);
        }

        //下载速度
        memset(&dp, 0, sizeof(TY_OBJ_DP_S));
        dp.dpid = DPID_BASE + 3;
        dp.type = PROP_VALUE;
        dp.value.dp_value = 800;
        ret = dev_report_dp_json_async(NULL, &dp, 1);
        if(OPRT_OK != ret) {
            PR_ERR("dev_report_dp_json_async ret:%d", ret);
        }

        //上传速度
        memset(&dp, 0, sizeof(TY_OBJ_DP_S));
        dp.dpid = DPID_BASE + 2;
        dp.type = PROP_VALUE;
        dp.value.dp_value = 300;
        ret = dev_report_dp_json_async(NULL, &dp, 1);
        if(OPRT_OK != ret) {
            PR_ERR("dev_report_dp_json_async ret:%d", ret);
        }
    }else if (p_dp_obj->value.dp_enum == 1) {
        memset(&dp, 0, sizeof(TY_OBJ_DP_S));
        dp.dpid = DPID_BASE + 4;
        dp.type = PROP_ENUM;
        dp.value.dp_enum = 2; //True False
        ret = dev_report_dp_json_async(NULL, &dp, 1);
        if(OPRT_OK != ret) {
            PR_ERR("dev_report_dp_json_async ret:%d", ret);
        }
    }

    return ret;
}

OPERATE_RET route_mqc_report_wifi_ssid(IN CONST TY_OBJ_DP_S *p_dp_obj)
{
    OPERATE_RET ret = OPRT_OK;
    TY_OBJ_DP_S dp = {0x0};
    CHAR_T ssid[256] = {0};
    if(NULL == p_dp_obj || PROP_STR != p_dp_obj->type) {
        PR_ERR("paramater is invalid");
    }

    dp.dpid = p_dp_obj->dpid;
    dp.type = p_dp_obj->type;
    dp.value.dp_str = p_dp_obj->value.dp_str;
    ret = dev_report_dp_json_async(NULL, &dp, 1);
    if(OPRT_OK != ret) {
        PR_ERR("dev_report_dp_json_async ret:%d", ret);
    }

    if (dp.dpid == (DPID_BASE + 5)) {
        if (memcmp(route_wifi[0].ssid, ssid, sizeof(ssid)) != 0)
            snprintf(route_wifi[0].ssid, sizeof(ssid), ssid);
    } else if (dp.dpid == (DPID_BASE + 10)) {
        if (memcmp(route_wifi[1].ssid, ssid, sizeof(ssid)) != 0)
            snprintf(route_wifi[1].ssid, sizeof(ssid), ssid);
    }

    return ret;
}

OPERATE_RET route_mqc_report_wifi_sig_level(IN CONST TY_OBJ_DP_S *p_dp_obj)
{
    OPERATE_RET ret = OPRT_OK;
    TY_OBJ_DP_S dp = {0x0};
    if(NULL == p_dp_obj || PROP_ENUM != p_dp_obj->type) {
        PR_ERR("paramater is invalid");
    }

    dp.dpid = p_dp_obj->dpid;
    dp.type = p_dp_obj->type;
    dp.value.dp_enum = p_dp_obj->value.dp_enum;
    ret = dev_report_dp_json_async(NULL, &dp, 1);
    if(OPRT_OK != ret) {
        PR_ERR("dev_report_dp_json_async ret:%d", ret);
    }

    if (dp.dpid == (DPID_BASE + 6)) {
        if (route_wifi[0].sig_level != (WIFI_SIG_LEVEL_E)dp.value.dp_enum)
            route_wifi[0].sig_level = (WIFI_SIG_LEVEL_E)dp.value.dp_enum;
    } else if (dp.dpid == (DPID_BASE + 11)) {
        if (route_wifi[1].sig_level != (WIFI_SIG_LEVEL_E)dp.value.dp_enum)
            route_wifi[1].sig_level = (WIFI_SIG_LEVEL_E)dp.value.dp_enum;
    }

    return ret;
}

OPERATE_RET route_mqc_report_wifi_enc_mode(IN CONST TY_OBJ_DP_S *p_dp_obj)
{
    OPERATE_RET ret = OPRT_OK;
    TY_OBJ_DP_S dp = {0x0};
    if(NULL == p_dp_obj || PROP_ENUM != p_dp_obj->type) {
        PR_ERR("paramater is invalid");
    }

    dp.dpid = p_dp_obj->dpid;
    dp.type = p_dp_obj->type;
    dp.value.dp_enum = p_dp_obj->value.dp_enum;
    ret = dev_report_dp_json_async(NULL, &dp, 1);
    if(OPRT_OK != ret) {
        PR_ERR("dev_report_dp_json_async ret:%d", ret);
    }

    if (dp.dpid == (DPID_BASE + 7)) {
        if (route_wifi[0].enc_mode != (WIFI_ENC_MODE_E)dp.value.dp_enum)
            route_wifi[0].enc_mode = (WIFI_ENC_MODE_E)dp.value.dp_enum;
    } else if (dp.dpid == (DPID_BASE + 12)) {
        if (route_wifi[1].enc_mode != (WIFI_ENC_MODE_E)dp.value.dp_enum)
            route_wifi[1].enc_mode = (WIFI_ENC_MODE_E)dp.value.dp_enum;
    }

    return ret;
}


OPERATE_RET route_mqc_report_wifi_switch(IN CONST TY_OBJ_DP_S *p_dp_obj)
{
    OPERATE_RET ret = OPRT_OK;
    TY_OBJ_DP_S dp = {0x0};
    if(NULL == p_dp_obj || PROP_BOOL != p_dp_obj->type) {
        PR_ERR("paramater is invalid");
    }

    dp.dpid = p_dp_obj->dpid;
    dp.type = p_dp_obj->type;
    dp.value.dp_bool = p_dp_obj->value.dp_bool;
    ret = dev_report_dp_json_async(NULL, &dp, 1);
    if(OPRT_OK != ret) {
        PR_ERR("dev_report_dp_json_async ret:%d", ret);
        return ret;
    }

    if (dp.dpid == (DPID_BASE + 8)) {
        if (route_wifi[0].enable != dp.value.dp_bool)
            route_wifi[0].enable = dp.value.dp_bool;
    } else if (dp.dpid == (DPID_BASE + 13)) {
        if (route_wifi[1].enable != dp.value.dp_bool)
            route_wifi[1].enable = dp.value.dp_bool;
    }

    return ret;
}

OPERATE_RET route_mqc_report_wifi_hide(IN CONST TY_OBJ_DP_S *p_dp_obj)
{
    OPERATE_RET ret = OPRT_OK;
    TY_OBJ_DP_S dp = {0x0};
    if(NULL == p_dp_obj || PROP_BOOL != p_dp_obj->type) {
        PR_ERR("paramater is invalid");
    }

    dp.dpid = p_dp_obj->dpid;
    dp.type = p_dp_obj->type;
    dp.value.dp_bool = p_dp_obj->value.dp_bool;
    ret = dev_report_dp_json_async(NULL, &dp, 1);
    if(OPRT_OK != ret) {
        PR_ERR("dev_report_dp_json_async ret:%d", ret);
        return ret;
    }

    if (dp.dpid == (DPID_BASE + 9)) {
        if (route_wifi[0].hide != dp.value.dp_bool)
            route_wifi[0].hide = dp.value.dp_bool;
    } else if (dp.dpid == (DPID_BASE + 14)) {
        if (route_wifi[1].hide != dp.value.dp_bool)
            route_wifi[1].hide = dp.value.dp_bool;
    }

    return ret;
}



// GW设备格式化指令数据下发入口
VOID __gw_dev_obj_dp_cmd_cb(IN CONST TY_RECV_OBJ_DP_S *dp)
{
    PR_DEBUG("GW Rev DP Obj Cmd t1:%d t2:%d CNT:%u Cid:%s", dp->cmd_tp, dp->dtt_tp, dp->dps_cnt, dp->cid);

    UINT_T index = 0;
    for(index = 0; index < dp->dps_cnt; index++) {
        CONST TY_OBJ_DP_S *p_dp_obj = dp->dps + index;
        PR_DEBUG("idx:%d dpid:%d type:%d ts:%u", index, p_dp_obj->dpid, p_dp_obj->type, p_dp_obj->time_stamp);
        switch (p_dp_obj->type) {
            case PROP_BOOL:     { PR_DEBUG("bool value:%d", p_dp_obj->value.dp_bool); break;}
            case PROP_VALUE:    { PR_DEBUG("INT value:%d", p_dp_obj->value.dp_value); break;}
            case PROP_STR:      { PR_DEBUG("str value:%s", p_dp_obj->value.dp_str); break;}
            case PROP_ENUM:     { PR_DEBUG("enum value:%u", p_dp_obj->value.dp_enum); break;}
            case PROP_BITMAP:   { PR_DEBUG("bits value:0x%X", p_dp_obj->value.dp_bitmap); break;}
            default:            { PR_ERR("idx:%d dpid:%d type:%d ts:%u is invalid", index, p_dp_obj->dpid, p_dp_obj->type, p_dp_obj->time_stamp); break;}
        }// end of switch

        switch (p_dp_obj->dpid) {
            case (DPID_BASE+4):     // 网速检测
                route_mqc_report_speed(p_dp_obj);
                break;
            case (DPID_BASE+5):     // WIFI-2.4G-名称
            case (DPID_BASE+10):    // WIFI-5G-名称
                route_mqc_report_wifi_ssid(p_dp_obj);
                //有iot设备接入路由，修改wifi用户名或密码后，需要开启二次配网
                //pegasus_server_second_start(10 * 60);
                break;
            case (DPID_BASE+6):     // WIFI-2.4G-信号强度
            case (DPID_BASE+11):    // WIFI-5G-信号强度
                route_mqc_report_wifi_sig_level(p_dp_obj);
                break;
            case (DPID_BASE+7):     // WIFI-2.4G-加密方式
            case (DPID_BASE+12):    // WIFI-5G-加密方式
                route_mqc_report_wifi_enc_mode(p_dp_obj);
                break;
            case (DPID_BASE+8):     // WIFI-2.4G-开关
            case (DPID_BASE+13):    // WIFI-5G-开关
                route_mqc_report_wifi_switch(p_dp_obj);
                break;
            case (DPID_BASE+9):     // WIFI-2.4G-隐藏开关
            case (DPID_BASE+14):    // WIFI-5G-隐藏开关
                route_mqc_report_wifi_hide(p_dp_obj);
                break;
            case (DPID_BASE+15):    // STA_DPID
                tuya_route_sta_data_parse(p_dp_obj->value.dp_str);
                break;
            default :
            PR_ERR("dpid:%d unkown", p_dp_obj->dpid);
            break;
        }
    }
}

// GW设备透传指令数据下发入口
VOID __gw_dev_raw_dp_cmd_cb(IN CONST TY_RECV_RAW_DP_S *dp)
{
    PR_DEBUG("SOC Rev DP Raw Cmd t1:%d t2:%d dpid:%d len:%u Cid:%s", dp->cmd_tp, dp->dtt_tp, dp->dpid, dp->len, dp->cid);

    // UserTODO

    // 用户处理完成之后需要主动上报最新状态，这里简单起见，直接返回收到的数据，认为处理全部成功。
    OPERATE_RET op_ret = dev_report_dp_raw_sync(dp->cid,dp->dpid,dp->data,dp->len,0);
    if(OPRT_OK != op_ret) {
        PR_ERR("dev_report_dp_json_async op_ret:%d",op_ret);
    }
}

// GW设备特定数据查询入口
VOID __gw_dev_dp_query_cb(IN CONST TY_DP_QUERY_S *dp_qry)
{
    PR_DEBUG("GW Rev DP Query Cmd Cid:%s", dp_qry->cid);

    if(dp_qry->cnt == 0) {
        PR_DEBUG("GW rev all dp query");
        // UserTODO
    }else {
        PR_DEBUG("GW rev dp query cnt:%d", dp_qry->cnt);
        UINT_T index = 0;
        for(index = 0; index < dp_qry->cnt; index++) {
            PR_DEBUG("rev dp query:%d", dp_qry->dpid[index]);
            // UserTODO
        }
    }
}

// GW外网状态变动回调
STATIC VOID __gw_dev_net_status_cb(IN CONST GW_BASE_NW_STAT_T stat)
{
    PR_DEBUG("network status:%d", stat);
    if (stat == GB_STAT_CLOUD_CONN) {
        tuya_route_rept_sta_allow_net("11:22:33:44:55:66", 1, DPID_BASE + 15);
    }
}

// GW远程拉取日志
VOID __gw_get_log_file_cb(OUT CHAR_T *file_name, IN CONST INT_T len)
{
    //提供日志压缩包（完整路径）
    snprintf(file_name, len, "%s", "/sdcard/tuya/tuya_log.tar.gz");
}

VOID __gw_dev_child_proc_exit_cb(VOID)
{
    // UserTODO
    PR_DEBUG("child proc exit");
    exit(0);
}

#include "prr.h"
static void flash_get_info(const char *cmd, char *result, int size)
{
    char buf[128] = {0};

    FILE *fp = popen(cmd, "r");
    if (fp == NULL)
        return ;
    fread(buf, sizeof(char), sizeof(buf), fp);
    pclose(fp);
    int len = strlen(buf);
    if(len  > 1 || '\n' == result[len -1]) {
        buf[len  - 1] = '\0';
    }
    snprintf(result, size, "%s", buf);
}
OPERATE_RET ty_wifi_get_ssid_pwd_cb(OUT INT8_T *ssid, IN INT_T slen, OUT INT8_T *pwd, IN INT_T plen)
{
    PR_DEBUG("pegasus get ssid pwd");
    prr_wifi_cfg_t pwc = {0x0};

#if 0
    int ret = prr_wifi_get_cfg(&pwc);
    if (ret != 0) {
        PR_ERR("get wifi cfg error: %d", ret);
        return OPRT_COM_ERROR;
    }
#else
    flash_get_info("flash get WLAN1_WSC_SSID", pwc.ssid, sizeof(pwc.ssid));
    flash_get_info("flash get WLAN1_WSC_PSK", pwc.pwd, sizeof(pwc.pwd));
#endif
    snprintf(ssid, slen, "%s", "netcore2.4G");//pwc.ssid);leike_netcore2
    snprintf(pwd, plen, "%s", "Net#9ka2");//pwc.pwd);

    PR_DEBUG("ssid[%s], passwd[%s]", ssid, pwd);

    return OPRT_OK;
}

/*****************************************************************************************************************/
// 产测相关
THRD_HANDLE tuya_factory_thrd_handle;
STATIC VOID __tuya_factory_manage(PVOID_T arg)
{
    TIME_T rf_test_start_tm = 0;
    BOOL_T rf_test_start = FALSE;
    UINT_T i = 0;
    while(1) {
        if (rf_test_start && (uni_time_get_posix() - rf_test_start_tm < 20)) {
            USHORT_T result = tuya_get_zigbee_rf_test_result();
            if (result > 0) {
                PR_DEBUG("get rf test result: %d", result);
                rf_test_start = FALSE;
            }
        }

        usleep(500 * 1000);
        i ++;

        if (0 == i % 60) {   //30s
            CHAR_T zigbee_ver[SW_VER_LEN+1] = {0x0};
            tuya_gw_get_zigbee_ver(zigbee_ver, sizeof(zigbee_ver));
            PR_DEBUG("get zigbee_ver:%s", zigbee_ver);

            PR_DEBUG("send rf packet");
            tuya_gw_zigbee_rf_test(11, 20);
            rf_test_start = TRUE;
            rf_test_start_tm = uni_time_get_posix();
        }
    }
}



int main(void)
{
    BOOL_T zigbee_enable = TRUE;
    TUYA_GW_ENV_S env;
    OPERATE_RET op_ret = OPRT_OK;

    printf("IOT SDK Version: %s \r\n", tuya_iot_get_sdk_info());
    printf("PRODUCT_KEY: %s \r\n", PRODUCT_KEY);
    printf("USER_SW_VER: %s \r\n", USER_SW_VER);
    printf("USER_DEV_IN_GW_SW_VER: %s \r\n", USER_DEV_IN_GW_SW_VER);
    printf("CFG_STORAGE_PATH: %s \r\n", CFG_STORAGE_PATH);
    printf("UUID: %s \r\n", UUID);
    printf("AUTHKEY: %s \r\n", AUTHKEY);

    memset(&env, 0 , sizeof(TUYA_GW_ENV_S));
    snprintf(env.storage_path, sizeof(env.storage_path), "%s", CFG_STORAGE_PATH);
    snprintf(env.product_key, sizeof(env.product_key), "%s", PRODUCT_KEY);
    snprintf(env.uuid, sizeof(env.uuid), "%s", UUID);
    snprintf(env.auth_key, sizeof(env.auth_key), "%s", AUTHKEY);
    snprintf(env.sw_ver, sizeof(env.sw_ver), "%s", "1.0.0");
    env.is_oem = TRUE;
    env.gw_stat_changed_cb = __gw_dev_status_changed_cb;
    env.gw_ug_inform_cb = __gw_dev_rev_upgrade_info_cb;
    env.gw_reset_cb = __gw_dev_reset_inform_cb;
    env.gw_reboot_cb = __gw_dev_reboot_cb;
    env.obj_dp_cmd_cb = __gw_dev_obj_dp_cmd_cb;
    env.raw_dp_cmd_cb = __gw_dev_raw_dp_cmd_cb;
    env.dp_query_cb = __gw_dev_dp_query_cb;
    env.nw_stat_cb = __gw_dev_net_status_cb;
    env.get_log_file = __gw_get_log_file_cb;
    env.get_sm_info_cb = ty_wifi_get_ssid_pwd_cb;
    env.zb_config.is_cts = TRUE;//开启硬件流控
    snprintf(env.zb_config.serial_port, sizeof(env.zb_config.serial_port), "%s", "/dev/ttyS1");
    snprintf(env.zb_config.tmp_dir, sizeof(env.zb_config.tmp_dir), "%s", "/tmp/");
    snprintf(env.zb_config.bin_dir, sizeof(env.zb_config.bin_dir), "%s", "/var/tuya/bin/");
    snprintf(env.zb_config.log_dir, sizeof(env.zb_config.log_dir), "%s", "/tmp/");
    env.child_proc_exit_cb = __gw_dev_child_proc_exit_cb;
    op_ret = tuya_gw_service_start(&env);
    if (OPRT_OK != op_ret) {
        printf("tuya_gw_start error:%d\n", op_ret);
        return op_ret;
    }

    op_ret = tuya_pegasus_test_start();
    if(OPRT_OK != op_ret) {
        PR_ERR("tuya_pegasus_test_start err:%d",op_ret);
        return -5;
    }
    op_ret = tuya_route_test_start();
    if(OPRT_OK != op_ret) {
        PR_ERR("tuya_route_test_start err:%d",op_ret);
        return -6;
    }

#if 0
    //for zigbee rf test
    THRD_PARAM_S thrd_param = {1024 * 6, TRD_PRIO_1, "tuya_factory_manage"};
    op_ret = CreateAndStart(&tuya_factory_thrd_handle, NULL, NULL,\
                            __tuya_factory_manage, NULL, &thrd_param);
    if (OPRT_OK != op_ret) {
        PR_ERR("create tuya_voice_thrd_handle thread fail %d", op_ret);
        return op_ret;
    }
#endif

    while (1) {
        sleep(5);
        
        // UserTODO
        OPERATE_RET ret = OPRT_OK;
        char line[256] = {0};
        memset(line, 0, sizeof(line));
        fgets(line, sizeof(line), stdin);
        printf("Your input: %c\r\n", line[0]);
        switch (line[0]) {
        case 'q':
            ret = tuya_gw_service_reset();
            if(OPRT_OK != ret) {
                PR_ERR("tuya_gw_service_reset err:%d", ret);
                return -7;
            }
            PR_DEBUG("tuya_gw_service_reset success");
            break;
        case 'e':
            tuya_local_add_dev_start(15*60);//超时时间15min
            break;
        case 'd':
            tuya_local_add_dev_stop();
            break;
        default:
            break;
        }

    }


    return 0;
}

