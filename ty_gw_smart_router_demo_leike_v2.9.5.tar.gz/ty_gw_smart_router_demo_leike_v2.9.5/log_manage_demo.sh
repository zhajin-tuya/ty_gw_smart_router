#!/bin/sh

TUYA_LOG_FILE=/tmp/tuya.log

LOG_PACK_DIR=/data/log/
LOG_FILE_DIR=/tmp/
LOG_FILE_NAME=tuya.log
log_file_max_size=3145728
log_pack_max_size=3145728

start_tuya_app() {

    cd /userdata/
    /userdata//tuyabox $TUYA_APP_PARM >> $TUYA_LOG_FILE 2>&1 &
    cd -
}


function log_check_pack_size() {	
    cd $LOG_PACK_DIR
    total_size=$(ls -l log_* | awk 'BEGIN {size=0;} {size=size+$5;} END{print size}')
    echo "total_size=$total_size"
    while [ "$total_size" -gt $log_pack_max_size ]
    do
        echo "delete $(ls -rt log_* | awk 'NR==1')"
        rm $(ls -rt log_* | awk 'NR==1')
        total_size=$(ls -l log_* | awk 'BEGIN {size=0;} {size=size+$5;} END{print size}')
    done
}



while true ; do
    ps -fe|grep tuyabox |grep -v grep 1>/dev/null 2>&1
    if [ $? -ne 0 ]; then
        echo "start tuya app....."
        start_tuya_app
    fi
    
    sleep 1

    if [ -f $TUYA_LOG_FILE ];then
    	if [ ! -d $LOG_PACK_DIR ];then
        	echo "create $LOG_PACK_DIR"
        	mkdir -p $LOG_PACK_DIR
		fi

        s=$(ls -l $TUYA_LOG_FILE | awk '{print $5}')
        if [ "$s" -gt $log_file_max_size ];then
            log_check_pack_size
            log_tar_date_name=log_$(date "+%Y%m%d%H%M%S").gz
            echo "save $LOG_PACK_DIR$log_tar_date_name"
            cd $LOG_FILE_DIR
            gzip -c $LOG_FILE_NAME > $log_tar_date_name
            cat /dev/null > $TUYA_LOG_FILE
            mv $log_tar_date_name $LOG_PACK_DIR 
            log_check_pack_size
            echo "erase $TUYA_LOG_FILE"
        fi                                                    
    else                                                          
    	echo "$TUYA_LOG_FILE is not exist!"                   
    fi

done

